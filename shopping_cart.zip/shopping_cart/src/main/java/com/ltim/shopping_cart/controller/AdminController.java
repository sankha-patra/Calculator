package com.ltim.shopping_cart.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ltim.shopping_cart.config.UserInfoUserDetails;
import com.ltim.shopping_cart.entity.Product;
import com.ltim.shopping_cart.entity.User;
import com.ltim.shopping_cart.service.ProductService;
import com.ltim.shopping_cart.service.UserService;

@RestController
public class AdminController {

    @Autowired
    private ProductService productService;

     @Autowired
    private UserService userService;
    

    @GetMapping("/api/ADMIN/products")
    public ResponseEntity<List<Product>> getAllProducts() {
        return new ResponseEntity<>(productService.getAllProducts(), HttpStatus.OK);
    }
     // gets all users and returns the list of users with status code OK
    // @GetMapping("/api/ADMIN/users")
    // public ResponseEntity<List<User>> getAllClients() {

        
    //     return new ResponseEntity<>(userService.getAllClients(), HttpStatus.OK);
    // }
    @GetMapping("/api/ADMIN/users")
    public ResponseEntity<List<String>> getAllClientUsernames() {
        List<User> allUsers = userService.getAllClients();
        List<String> usernames = new ArrayList<>();
    
        for (User user : allUsers) {
            usernames.add(user.getUsername());
        }
    
        return ResponseEntity.ok(usernames);
    }




     @PostMapping("/api/ADMIN/register_product")
    public Product createProduct(@RequestBody Product product) {
        return productService.create(product);
    }

    
    @PutMapping("/api/ADMIN/update_product/{productId}")
    public Product updateProduct(@PathVariable Long productId, @RequestBody Product updatedProduct) {
        return productService.update(productId, updatedProduct);
    }
    @PutMapping("/api/ADMIN/update_user/{userId}")
    public ResponseEntity<User> updateUser(@PathVariable Long userId, @RequestBody User user) {
        return new ResponseEntity<>(userService.updateUser(userId, user), HttpStatus.OK);
    }

    @DeleteMapping("/api/ADMIN/delete/{userId}")
    public ResponseEntity<String> deleteClient(@PathVariable Long userId){
            boolean isdeleted=userService.deleteClient(userId);
            if(isdeleted==true){
                return new ResponseEntity<>("User deleted successfully",HttpStatus.OK);
            }
            else{
                return new ResponseEntity<>("Unable to delete",HttpStatus.BAD_REQUEST);
            }   
     }


    
}
