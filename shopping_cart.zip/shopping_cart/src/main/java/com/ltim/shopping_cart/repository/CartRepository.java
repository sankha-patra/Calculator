package com.ltim.shopping_cart.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ltim.shopping_cart.entity.Cart;

public interface CartRepository extends JpaRepository<Cart,Long>{
     @Query("SELECT c FROM Cart c WHERE c.user.username = :username")
    Cart findCartByUsername(@Param("username") String username);
}
