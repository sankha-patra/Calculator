package com.ltim.shopping_cart.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltim.shopping_cart.entity.Product;
import com.ltim.shopping_cart.entity.User;
import com.ltim.shopping_cart.repository.ProductRepository;
import com.ltim.shopping_cart.repository.UserRepository;

@Service
public class ProductService {
    
    @Autowired
    private ProductRepository repository;

    

    @Autowired
    private UserRepository userRepository;

    public Product create(Product product) {
        return repository.save(product);
    }

    public Product findById(Long id) {
        Optional<Product> optionalProduct = repository.findById(id);
        return optionalProduct.orElse(null);
    }

    public List<Product> getAllProducts() {
        return repository.findAll();
    }

    public List<Product> getProductsForUser(long userId) {

       
        User user = userRepository.findById(userId).get();
        if (user == null) {
            //if user not found return empty
            return List.of();
        }

       
        Set<Product> products = user.getProducts();
        return List.copyOf(products);
    }

    public Product update(Long id, Product updatedProduct) {
        Product existingProduct = findById(id);
        if (existingProduct != null) {
            existingProduct.setName(updatedProduct.getName());
            existingProduct.setPrice(updatedProduct.getPrice());
            existingProduct.setCategory(updatedProduct.getCategory());
            existingProduct.setDescription(updatedProduct.getDescription());
            existingProduct.setIn_stock(updatedProduct.isIn_stock());

          
            return repository.save(existingProduct);
        }
        return null; // when Product not found
    }

    public boolean delete(Long userId, Long productId) {
        User user = userRepository.findById(userId).orElse(null);
    Product product = repository.findById(productId).orElse(null);

    if (user != null && product != null) {
        // remove product from the user
        user.getProducts().remove(product);
        userRepository.save(user); // Save user to update the association
        return true; 
    }
    return false; // If User or product not found
    }

    public boolean purchaseProduct(long userId, long productId) {

        // Check if the user has the CLIENT role
        Optional<User> userOptional = userRepository.findById(userId);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            if ("CLIENT".equals(user.getRole())) {
                // Retrieve the product by ID
                Optional<Product> productOptional = repository.findById(productId);
                if (productOptional.isPresent()) {

                    Product product = productOptional.get();
                    int currentQuantity = product.getQuantity();
                    // boolean productInCart = user.getProducts().contains(product);
                    boolean productInCart = user.getCart().getProductsInCart().contains(product);
                    Set<Product>  pl = user.getCart().getProductsInCart();
                    System.out.println("hello");
                    
                    if (currentQuantity > 0 && productInCart) {
                        // Decrease product quantity after purchasing
                        System.out.println("adding");
                        product.setQuantity(currentQuantity - 1);
                        user.getCart().getProductsInCart().remove(product);
                        if (currentQuantity == 1) {
                            // out of stock when quantity reaches zero
                            
                            product.setIn_stock(false);
                        }
    
                        // Saving the updated product and user
                        double productPrice = product.getPrice();
                        double totalCost = user.getTotalCost() + productPrice;
                        user.setTotalCost(totalCost);
                        repository.save(product);
                        user.getProducts().add(product);
                        userRepository.save(user);
    
                        return true;
                    }
                }
            }
        }
  
        return false;
    }
}
