package com.ltim.shopping_cart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ltim.shopping_cart.entity.Product;


public interface ProductRepository extends JpaRepository<Product, Long> {
    
}