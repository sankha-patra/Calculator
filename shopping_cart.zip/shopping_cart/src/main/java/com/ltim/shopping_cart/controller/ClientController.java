package com.ltim.shopping_cart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.ltim.shopping_cart.config.UserInfoUserDetails;
import com.ltim.shopping_cart.entity.Cart;
import com.ltim.shopping_cart.entity.Product;
import com.ltim.shopping_cart.entity.User;
import com.ltim.shopping_cart.service.CartService;
import com.ltim.shopping_cart.service.ProductService;


@RestController
public class ClientController {

     @Autowired
    private ProductService productService;

    @Autowired
    private CartService cartService;

   
    private long getUserIdFromAuthentication() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserInfoUserDetails userDetails = (UserInfoUserDetails) authentication.getPrincipal();
           
            return userDetails.getUserID();
        }
 
        return -1L;
    }
    public String getCurrentUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.getPrincipal() instanceof UserDetails) {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            return userDetails.getUsername();
        }

        return null; // Returning null if no user is authenticated
    }

    
    // get all productsfor particular user and return the list with status code 200 (OK)
    // @GetMapping("/api/CLIENT/{userId}/products")
    // public List<Product> getProductsForUser(@PathVariable int userId) {
        
    //     return productService.getProductsForUser(userId);
    // }

    @GetMapping("/api/CLIENT/products_user")
    public List<Product> getProductsForUser() {
        long userId = getUserIdFromAuthentication(); 
        
        return productService.getProductsForUser(userId);
    }

    @DeleteMapping("/api/CLIENT/{userId}/prod/{productId}")
    public boolean deleteProductFromUser(@PathVariable Long userId, @PathVariable Long productId) {
        return productService.delete(userId, productId);
    }

    @GetMapping("/api/CLIENT/{productId}")
    public Product getProductById(@PathVariable Long productId) {
        return productService.findById(productId);
    }

    @GetMapping("/api/CLIENT/products")
    public ResponseEntity<List<Product>> getAllProducts() {
        return new ResponseEntity<>(productService.getAllProducts(), HttpStatus.OK);
    }

    @PostMapping("/api/CLIENT/purchase/{productId}")
    public ResponseEntity<String> purchaseProduct(@PathVariable long productId) {
        
        long userId = getUserIdFromAuthentication(); 

        if (productService.purchaseProduct(userId, productId)) {
            return ResponseEntity.ok("Product purchased successfully!");
        } else {
            return ResponseEntity.badRequest().body("Unable to purchase the product.");
        }
    }

    @GetMapping("/api/CLIENT/cart")
    public List<Product> getProductsInCartForLoggedInUser() {
        // Get the logged-in user's username
        String username = getCurrentUsername();

        // Calling CartService to retrieve cart items
        return cartService.getProductsInCartByUsername(username);
    }

    @PostMapping("/api/CLIENT/add_cart/{productId}")
    public ResponseEntity<Boolean> addToCart(@PathVariable Long productId) {
        // Extracting user ID and product ID from the request
        
        long userId = getUserIdFromAuthentication(); 
        // Calling  CartService to add the product to the user's cart
        boolean addedToCart = cartService.addToCart(userId, productId);

        if (addedToCart) {
            return ResponseEntity.ok(true);
        } else {
            return ResponseEntity.badRequest().body(false);
        }
    }
    @PostMapping("/api/CLIENT/createCart")
    public ResponseEntity<Cart> createOrUpdateCart(@RequestBody User user) {
        Cart cart = cartService.createOrUpdateCartForUser(user);
        if (cart != null) {
            return ResponseEntity.ok(cart);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); 
        }
    }
   

}
